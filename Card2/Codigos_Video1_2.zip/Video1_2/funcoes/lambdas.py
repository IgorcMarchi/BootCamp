from functools import reduce

alunos = [
    {'nome': 'Ana', 'nota': '7.2'},
    {'nome': 'Breno', 'nota': '8.1'},
    {'nome': 'Claudia', 'nota': '8.7'},
    {'nome': 'Pedro', 'nota': '6.4'},
    {'nome': 'Rafael', 'nota': '6.7'},
]


def aluno_aprovado(aluno): lambda aluno : float(aluno['nota']) >= 7
alunos_aprovados = list(filter(aluno_aprovado, alunos))

# aluno_honra =  lambda aluno: float(aluno['nota']) >= 9
def obter_nota(aluno): return aluno['nota']


def somar(a, b): return float(a) + float(b)


# alunos_aprovados = filter(aluno_aprovado, alunos) esse é um comando pro python 2 precisa utliziar o list no python 3
alunos_aprovados = list(filter(aluno_aprovado, alunos))
notas_alunos_aprovados = list(map(obter_nota, alunos_aprovados))
total = reduce(somar, notas_alunos_aprovados, 0)

print(total/ len(alunos_aprovados))
