
def saudacao(nome='Pessoa', idade=20):
    print(f'Bom dia {nome}!\nVocê nem parece ter {idade} anos!')

# def saudacao():
#    print('Bom dia!')


def soma_emulti(a, b, x):
    return a + b * x


if (__name__ == '__main__'):
    saudacao('Ana', idade=30)
