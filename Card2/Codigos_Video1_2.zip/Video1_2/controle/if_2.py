a = 'valor'  # Existe/ True
a = 0  # é zero/ False
a = -0.0001  # Existe/ True
a = ''  # Vazio/ False
a = ' '  # Existe/ True
a = []  # vazio/ False
a = {}  # Vazio/ False

if a:
    print('Existe!!!')
else:
    print('Não existe ou zero ou vazio...')
