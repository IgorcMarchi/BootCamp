
x = 10
y = 5

# +3 prefix
# x++ postfix
# x + y infix

print(x + y) # 10+5 retorna 15
print(x - y) # 10-5 retorna 5
print(x * y) # 10*5 retorna 50
print(x / y) # 10/5 retorna 2 
print(x % y) # 10%5 retorna 0
print(x**y) # 10**5 retorrna 100000

par = 34
impar = 33

print(par % 2 == 0)  # Fala se a condição é verdadeiro ou falso
print(impar % 2 == 1)
