# Atribui no resultado seja (atribuir valor, somar, subtrair, multiplicar, dividir, resto)
resultado = 2
resultado += resultado # resultado = resultado + resultado
resultado += 3  # resultado = resultado + 3
resultado -= 1  # resultado = resultado - 1
resultado *= 4  # resultado = resultado * 4
resultado /= 2  # resultado = resultado / 2
resultado %= 6  # resultado = resultado % 6
print(resultado)

resultado = 'texto'
print(resultado)
