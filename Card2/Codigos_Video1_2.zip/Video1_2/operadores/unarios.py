y = 4

print(not False)  # Inverte o valor, se for False vira True e vice-versa
print(not True)
print(-3)  # Acrescenta um sinal de menos
print(-y)
print(+3)

w = 12
# w++ # não é possivel
print(w)
