x = 7
y = 5

# Fala se a condição é True ou false
print(x > y)  # Se x é maior que y
print(x >= y) # se x é maior ou igual a y
print(x < y) # Se x é menor que y
print(x <= y) # Se x é mneor ou igual a y
print(x == y) # Se o valor de x é igual ao do y
print(x != y) # Se o valor de x é diferente do de y

print('5' != y)
