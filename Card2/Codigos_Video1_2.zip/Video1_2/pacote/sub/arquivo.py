print(__name__)  # Mostra o nome do módulo
print(__package__)  # Mostra onde está se encontrando o modulo (dentro da pasta)

print(abs(-321))  # O número absoluto desconsidera os valores negativos
