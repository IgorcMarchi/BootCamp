
aluno = {
    'nome': 'Pedro Henrique',
    'nota': 9.2,
    'ativo': True
}
print(type(aluno))
print(aluno['nome'])  # Mostra valor que esta dentro da chave
print(aluno['nota'])
print(aluno['ativo'])
print(len(aluno))  # mostra o tamanho
