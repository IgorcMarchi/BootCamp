nomes = ('Ana', 'Bia', 'Gui', 'leonardo', 'Ana')

print('Bia' in nomes)  # Se enncontra ou não dentro da tupla

print(nomes[0])  # Mostra apenas a posição 0
print(nomes[1:3])  # Vai da posição 1 até a posição 2
print(nomes[1: -1])  # Vai da posição 1 até a penúltima
print(nomes[2:])  # Vai até a posição 2
print(nomes[:-2])  # vai do começo até o anti penúltimo

print(len(nomes))  # Mostra o tamanho da tupla
print(type(nomes))  # Mostra que é uma classe tupla

print(nomes)
